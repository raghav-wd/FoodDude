<?php
include "../includes/config.php";

$sql = "SELECT * FROM z".$_COOKIE['fooddude'];
$res = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($res);

echo $row['maggi'];
?>